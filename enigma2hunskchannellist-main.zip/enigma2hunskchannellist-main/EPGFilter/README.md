# EPGFilter

Erre a mappára alap esetben nincs szükség. A channel_id_filter.conf elvégzi a szükséges csatorna szűrést.